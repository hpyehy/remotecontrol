﻿// RemoteControl.cpp : 此文件包含 "main" 函数。程序执行将在此处开始并结束。
//

#include "pch.h"
#include "framework.h"
#include "RemoteControl.h"
#include "ServerSocket.h"
#include <direct.h>
#include <atlimage.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#endif
//#pragma comment( linker, "/subsystem:windows /entry:WinMainCRTStartup" )
//#pragma comment( linker, "/subsystem:windows /entry:mainCRTStartup" )
//#pragma comment( linker, "/subsystem:console /entry:mainCRTStartup" )
//#pragma comment( linker, "/subsystem:console /entry:WinMainCRTStartup" )

// 唯一的应用程序对象  
// 分支001
CWinApp theApp;

using namespace std;

void Dump(BYTE* pData, size_t nSize)
{//以十六进制格式打印数据
    std::string strOut;
    for (size_t i = 0; i < nSize; i++)
    {
        char buf[8] = "";
        if (i > 0 && (i % 16 == 0))strOut += "\n";
        snprintf(buf, sizeof(buf), "%02X ", pData[i] & 0xFF);
        strOut += buf;
    }
    strOut += "\n";
    OutputDebugStringA(strOut.c_str());
}

int MackeDriverInfo() {
    std::string result;
    for (int i = 1; i <= 26; i++) {
        if (_chdrive(i) == 0) {// _chdrive(i) 判断磁盘 i 是否存在
            if (result.size() > 0)
                result += ',';
            result += 'A' + i - 1;
        }
    }
    // CPacket(WORD nCmd, const BYTE* pData, size_t nSize)
    CPacket pack(1, (BYTE*)result.c_str(), result.size());//打包用的
    Dump((BYTE*)pack.Data(), pack.Size());
    //CServerSocket::getInstance()->Send(pack);
    return 0;
}

#include <stdio.h>
#include <io.h>
#include <list>

// 函数每找到一个文件，就发送一次 
int MakeDirectoryInfo() {
    std::string strPath;
    //std::list<FILEINFO> lstFileInfos;
    if (CServerSocket::getInstance()->GetFilePath(strPath) == false) {//从客户端请求的 CPacket 数据包中提取路径 strPath
        OutputDebugString(_T("当前的命令，不是获取文件列表，命令解析错误！！"));
        return -1;
    }

    // 尝试进入目录
    // _chdir 切换到指定目录，!= 0为切换失败
    if (_chdir(strPath.c_str()) != 0) {
        FILEINFO finfo;
        finfo.HasNext = FALSE;//表示目录无法访问
        //封装成数据包 CPacket(2, (BYTE)&finfo, sizeof(finfo)) 并发送，通知客户端访问失败
        CPacket pack(2, (BYTE*)&finfo, sizeof(finfo));//CPacket(WORD nCmd, const BYTE* pData, size_t nSize)
        CServerSocket::getInstance()->Send(pack);
        OutputDebugString(_T("没有权限访问目录！！"));
        return -2;
    }

    _finddata_t fdata;
    int hfind = 0;
    //_findfirst 查找当前目录下的第一个文件，fdata 存储查找到的文件信息（如文件名、属性等）
    //返回值 hfind 是搜索句柄，用于后续 _findnext() 继续查找下一个文件
    if ((hfind = _findfirst("*", &fdata)) == -1) {
        
        OutputDebugString(_T("没有找到任何文件！！"));
        FILEINFO finfo;
        finfo.HasNext = FALSE;
        CPacket pack(2, (BYTE*)&finfo, sizeof(finfo));
        CServerSocket::getInstance()->Send(pack);
        return -3;
    }

    //没有出错，开始记录文件信息
    int count = 0;
    do {
        FILEINFO finfo;
        //判断是否为目录（通过 fdata.attrib & _A_SUBDIR ），subdir 就是目录
        finfo.IsDirectory = (fdata.attrib & _A_SUBDIR) != 0;
        memcpy(finfo.szFileName, fdata.name, strlen(fdata.name));//拷贝文件名
        TRACE("%s\r\n", finfo.szFileName);
        CPacket pack(2, (BYTE*)&finfo, sizeof(finfo));//封装数据包
        CServerSocket::getInstance()->Send(pack);//发送给客户端
        count++;
    } while (!_findnext(hfind, &fdata));//返回值：0：成功找到下一个文件，并将信息存入 fdata , -1 ：没有找到下一个文件（已经遍历完所有文件）或出现错误。

    TRACE("server: count = %d\r\n", count);
    //最后这段代码的作用是向客户端明确通知文件列表已经发送完毕
    FILEINFO finfo;
    finfo.HasNext = FALSE;// HasNext 为 false 说明没有下一个文件了
    //将finfo中的信息存入CPacket类型的对象中
    CPacket pack(2, (BYTE*)&finfo, sizeof(finfo));
    //将CPacket类型的对象通过Data函数转化为char*类型的二进制数据流便于发送
    CServerSocket::getInstance()->Send(pack);
    return 0;
}

int RunFile() {
    std::string strPath;
    CServerSocket::getInstance()->GetFilePath(strPath);  // 获取客户端发送的文件路径
    ShellExecuteA(NULL, NULL, strPath.c_str(), NULL, NULL, SW_SHOWNORMAL);  // 运行文件

    CPacket pack(3, NULL, 0);  // 创建响应数据包，通知客户端
    CServerSocket::getInstance()->Send(pack);  // 发送通知
    return 0;
}

#pragma warning(disable:4966) // fopen sprintf strcpy strstr  无视 4996 错误
int DownloadFile() {
    std::string strPath;
    CServerSocket::getInstance()->GetFilePath(strPath);  // 获取客户端请求的文件路径
    long long data = 0;
    FILE* pFile = NULL;
    // 以只读二进制模式打开文件
    // pFile是输出参数，存储打开的文件指针，"rb" 只读二进制
    errno_t err = fopen_s(&pFile, strPath.c_str(), "rb");
    // 表示文件不存在（返回0说明文件打开成功，2（ENOENT）文件不存在，13（EACCES）无权限访问）
    if (err != 0) { // 失败 发送 CPacket(4, 0, 8) 
        CPacket pack(4, (BYTE*)&data, 8);  // 发送一个 "文件不存在" 标志
        CServerSocket::getInstance()->Send(pack);
        return -1;
    }

    if (pFile != NULL) {
        fseek(pFile, 0, SEEK_END);// 跳转到文件末尾，用于获取文件大小 (0表示不移动)
        data = _ftelli64(pFile);  // 获取文件大小
        CPacket head(4, (BYTE*)&data, 8);  // 发送文件大小信息
        CServerSocket::getInstance()->Send(head);

        fseek(pFile, 0, SEEK_SET);// 将文件指针移回开头，准备读取数据
        char buffer[1024] = "";  // 定义缓冲区
        size_t rlen = 0;
        do {
            rlen = fread(buffer, 1, 1024, pFile);  // 读取 1024 字节
            CPacket pack(4, (BYTE*)buffer, rlen);  // 封装数据包
            CServerSocket::getInstance()->Send(pack);  // 发送数据
        } while (rlen >= 1024);

        fclose(pFile);
    }
    CPacket pack(4, NULL, 0);  // 发送结束标志
    CServerSocket::getInstance()->Send(pack);
    return 0;
}


int MouseEvent()
{
    MOUSEEV mouse;
    if (CServerSocket::getInstance()->GetMouseEvent(mouse)) {
        DWORD nFlags = 0;

        switch (mouse.nButton) {
        case 0://左键
            nFlags = 1;
            break;
        case 1://右键
            nFlags = 2;
            break;
        case 2://中键
            nFlags = 4;
            break;
        case 4://没有按键
            nFlags = 8;
            break;
        }
        // 这里只处理鼠标按下的情况，鼠标未按下的情况下面处理，这里不能重复处理
        // 如果按下和释放的位置不一致，可能会出现意外效果，比如拖动窗口，拖动文件的时候
        if (nFlags != 8)SetCursorPos(mouse.ptXY.x, mouse.ptXY.y);

        switch (mouse.nAction)
        {
        case 0://单击
            nFlags |= 0x10;
            break;
        case 1://双击
            nFlags |= 0x20;
            break;
        case 2://按下
            nFlags |= 0x40;
            break;
        case 3://放开
            nFlags |= 0x80;
            break;
        default:
            break;
        }

        TRACE("mouse event : %08X x %d y %d\r\n", nFlags, mouse.ptXY.x, mouse.ptXY.y);

        switch (nFlags)
        {
        case 0x21://左键双击
            mouse_event(MOUSEEVENTF_LEFTDOWN, 0, 0, 0, GetMessageExtraInfo());
            mouse_event(MOUSEEVENTF_LEFTUP, 0, 0, 0, GetMessageExtraInfo());
        case 0x11://左键单击
            mouse_event(MOUSEEVENTF_LEFTDOWN, 0, 0, 0, GetMessageExtraInfo());
            mouse_event(MOUSEEVENTF_LEFTUP, 0, 0, 0, GetMessageExtraInfo());
            break;
        case 0x41://左键按下
            mouse_event(MOUSEEVENTF_LEFTDOWN, 0, 0, 0, GetMessageExtraInfo());
            break;
        case 0x81://左键放开
            mouse_event(MOUSEEVENTF_LEFTUP, 0, 0, 0, GetMessageExtraInfo());
            break;
        case 0x22://右键双击
            mouse_event(MOUSEEVENTF_RIGHTDOWN, 0, 0, 0, GetMessageExtraInfo());
            mouse_event(MOUSEEVENTF_RIGHTUP, 0, 0, 0, GetMessageExtraInfo());
        case 0x12://右键单击
            mouse_event(MOUSEEVENTF_RIGHTDOWN, 0, 0, 0, GetMessageExtraInfo());
            mouse_event(MOUSEEVENTF_RIGHTUP, 0, 0, 0, GetMessageExtraInfo());
            break;
        case 0x42://右键按下
            mouse_event(MOUSEEVENTF_RIGHTDOWN, 0, 0, 0, GetMessageExtraInfo());
            break;
        case 0x82://右键放开
            mouse_event(MOUSEEVENTF_RIGHTUP, 0, 0, 0, GetMessageExtraInfo());
            break;
        case 0x24://中键双击
            mouse_event(MOUSEEVENTF_MIDDLEDOWN, 0, 0, 0, GetMessageExtraInfo());
            mouse_event(MOUSEEVENTF_MIDDLEUP, 0, 0, 0, GetMessageExtraInfo());
        case 0x14://中键单击
            mouse_event(MOUSEEVENTF_MIDDLEDOWN, 0, 0, 0, GetMessageExtraInfo());
            mouse_event(MOUSEEVENTF_MIDDLEUP, 0, 0, 0, GetMessageExtraInfo());
            break;
        case 0x44://中键按下
            mouse_event(MOUSEEVENTF_MIDDLEDOWN, 0, 0, 0, GetMessageExtraInfo());
            break;
        case 0x84://中键放开
            mouse_event(MOUSEEVENTF_MIDDLEUP, 0, 0, 0, GetMessageExtraInfo());
            break;
        case 0x08://单纯的鼠标移动
            mouse_event(MOUSEEVENTF_MOVE, mouse.ptXY.x, mouse.ptXY.y, 0, GetMessageExtraInfo());
            break;
        }
        CPacket pack(4, NULL, 0);
        CServerSocket::getInstance()->Send(pack);
    }
    else {
        OutputDebugString(_T("获取鼠标操作参数失败！！"));
        return -1;
    }
    return 0;
}

int SendScreen()
{
    CImage screen;//GDI
    HDC hScreen = ::GetDC(NULL);//整个屏幕的设备上下文( HDC ), HDC 是一个句柄，表示绘图对象，用于绘制图形或截图
    int nBitPerPixel = GetDeviceCaps(hScreen, BITSPIXEL);//24   ARGB8888 32bit // RGB888 24bit //RGB565  // RGB444
    int nWidth = GetDeviceCaps(hScreen, HORZRES); // 屏幕宽度
    int nHeight = GetDeviceCaps(hScreen, VERTRES);// 屏幕高度
    screen.Create(nWidth, nHeight, nBitPerPixel); // 创建一个空白 CImage ，大小与屏幕一致
    //复制屏幕像素到 CImage，screen.GetDC()是目标 HDC（绘制到 CImage），nHeight是 源HDC，SRCCOPY表示拷贝
    BitBlt(screen.GetDC(), 0, 0, nWidth, nHeight, hScreen, 0, 0, SRCCOPY);
    ReleaseDC(NULL, hScreen);//释放屏幕 HDC ，避免资源泄露

    HGLOBAL hMem = GlobalAlloc(GMEM_MOVEABLE, 0);//创建一个可调整的全局内存对象，初始值为 0，用于存储 PNG 数据
    if (hMem == NULL)return -1;
    IStream* pStream = NULL;//创建 IStream（内存流，用于存储各种数据），用于写入 PNG
    //创建内存流 pStream，并绑定 hMem：创建基于 HGLOBAL（全局内存）的 IStream（流对象），允许 pStream 作为内存流来存储数据
    HRESULT ret = CreateStreamOnHGlobal(hMem, TRUE, &pStream);//TRUE 自动释放 hMem（当 pStream 释放时，自动释放 hMem）
    
    // 测试生成图片的速度
    //for (int i = 0; i < 10; i++) {
    //    DWORD tick = GetTickCount64();//获取时间戳
    //    screen.Save(_T("test2020.png"), Gdiplus::ImageFormatPNG);
    //    TRACE("png %d\r\n", GetTickCount64() - tick);
    //    tick = GetTickCount64();
    //    screen.Save(_T("test2020.jpg"), Gdiplus::ImageFormatJPEG);
    //    TRACE("jpg %d\r\n", GetTickCount64() - tick) ;
    //}

    if (ret == S_OK) {
        screen.Save(pStream, Gdiplus::ImageFormatPNG);//用 PNG 耗的带宽更少一些，将 PNG 保存到 pStream之中
        LARGE_INTEGER bg = { 0 };// bg 表示偏移量为0，即pStream的头部
        pStream->Seek(bg, STREAM_SEEK_SET, NULL);//将流指针移动到开头，以便后续读取数据(之前保存的时候指针到末尾了)
        
        //锁定全局内存 hMem 并获取其指针，使得可以直接访问其中的数据。转换为 PBYTE（BYTE* ），方便以字节方式操作数据
        PBYTE pData = (PBYTE)GlobalLock(hMem);
        SIZE_T nSize = GlobalSize(hMem);
        CPacket pack(6, pData, nSize);
        CServerSocket::getInstance()->Send(pack);
        GlobalUnlock(hMem);
    }
    
    pStream->Release();
    GlobalFree(hMem);
    screen.ReleaseDC();
    return 0;
}

#include "LockInfoDialog.h"
CLockInfoDialog dlg;
unsigned threadid = 0;

unsigned __stdcall threadLockDlg(void* arg)
{
    TRACE("%s(%d):%d\r\n", __FUNCTION__, __LINE__, GetCurrentThreadId());
    dlg.Create(IDD_DIALOG_INFO, NULL);
    dlg.ShowWindow(SW_SHOW);
    //遮蔽后台窗口
    CRect rect;
    rect.left = 0;
    rect.top = 0;
    rect.right = GetSystemMetrics(SM_CXFULLSCREEN);//w1
    rect.bottom = GetSystemMetrics(SM_CYFULLSCREEN);
    rect.bottom = LONG(rect.bottom * 1.10);
    TRACE("right = %d bottom = %d\r\n", rect.right, rect.bottom);
    dlg.MoveWindow(rect);
    CWnd* pText = dlg.GetDlgItem(IDC_STATIC);
    if (pText) {
        CRect rtText;
        pText->GetWindowRect(rtText);
        int nWidth = rtText.Width();//w0
        int x = (rect.right - nWidth) / 2;
        int nHeight = rtText.Height();
        int y = (rect.bottom - nHeight) / 2;
        pText->MoveWindow(x, y, rtText.Width(), rtText.Height());
    }

    //窗口置顶
    dlg.SetWindowPos(&dlg.wndTopMost, 0, 0, 0, 0, SWP_NOSIZE | SWP_NOMOVE);
    //限制鼠标功能
    ShowCursor(false);
    //隐藏任务栏
    ::ShowWindow(::FindWindow(_T("Shell_TrayWnd"), NULL), SW_HIDE);
    //限制鼠标活动范围
    dlg.GetWindowRect(rect);
    rect.left = 0;
    rect.top = 0;
    rect.right = 1;
    rect.bottom = 1;
    ClipCursor(rect);
    MSG msg;
    while (GetMessage(&msg, NULL, 0, 0)) {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
        if (msg.message == WM_KEYDOWN) {
            TRACE("msg:%08X wparam:%08x lparam:%08X\r\n", msg.message, msg.wParam, msg.lParam);
            if (msg.wParam == 0x41) {//按下a键 退出  ESC（1B)
                break;
            }
        }
    }
    ClipCursor(NULL);
    //恢复鼠标
    ShowCursor(true);
    //恢复任务栏
    ::ShowWindow(::FindWindow(_T("Shell_TrayWnd"), NULL), SW_SHOW);
    dlg.DestroyWindow();
    _endthreadex(0);
    return 0;
}

int LockMachine()
{
    if ((dlg.m_hWnd == NULL) || (dlg.m_hWnd == INVALID_HANDLE_VALUE)) {
        //_beginthread(threadLockDlg, 0, NULL);
        _beginthreadex(NULL, 0, threadLockDlg, NULL, 0, &threadid);
        TRACE("threadid=%d\r\n", threadid);
    }
    CPacket pack(7, NULL, 0);
    CServerSocket::getInstance()->Send(pack);
    return 0;
}

int UnlockMachine()
{
    //dlg.SendMessage(WM_KEYDOWN, 0x41, 0x01E0001);
    //::SendMessage(dlg.m_hWnd, WM_KEYDOWN, 0x41, 0x01E0001);
    PostThreadMessage(threadid, WM_KEYDOWN, 0x41, 0);
    CPacket pack(8, NULL, 0);
    CServerSocket::getInstance()->Send(pack);
    return 0;
}


int main()
{
    int nRetCode = 0;

    HMODULE hModule = ::GetModuleHandle(nullptr);

    if (hModule != nullptr)
    {
        // 初始化 MFC 并在失败时显示错误
        if (!AfxWinInit(hModule, nullptr, ::GetCommandLine(), 0))
        {
            // TODO: 在此处为应用程序的行为编写代码。
            wprintf(L"错误: MFC 初始化失败\n");
            nRetCode = 1;
        }
        else
        {
            // TODO: 在此处为应用程序的行为编写代码。
            //服务器套接字：socket、bind、listen、accept、read、write、close
            //CServerSocket::getInstance();
            //CServerSocket* pserver = CServerSocket::getInstance();
            //int count = 0;
            //while(CServerSocket::getInstance() !=NULL) {
            //    if (pserver->InitSocket() == false) {
            //        MessageBox(NULL, _T("网络初始化异常，未能成功初始化，请检查网络状态！"), _T("网络初始化失败"), MB_OK | MB_ICONERROR);
            //        exit(0);
            //    }
            //    if (pserver->AcceptClient() == false) {
            //        if (count >= 3) {
            //            MessageBox(NULL, _T("多次无法正常接入用户，结束程序！"), _T("接入用户失败！"), MB_OK | MB_ICONERROR);
            //            exit(0);
            //        }
            //        MessageBox(NULL, _T("无法正常接入用户，自动重试"), _T("接入用户失败！"), MB_OK | MB_ICONERROR);
            //        count++;
            //    }
            //    int ret = pserver->DealCommand();
            //}
            
            int nCmd = 6;
            switch (nCmd) {
            case 1://查看磁盘分区
                MackeDriverInfo();
                break;
            case 2://查看指定目录下面的文件
                MakeDirectoryInfo();
                break;
            case 3://打开文件
                RunFile();
                break;
            case 4:
                DownloadFile();
                break;
            case 5:
                MouseEvent();
                break;
            case 6:
                SendScreen();
                break;
            case 7:
                LockMachine();
            case 8:
                UnlockMachine();
                break;
            case 9:
                
                break;
            case 10:
                
                break;
            }
            
            
        }
    }
    else
    {
        // TODO: 更改错误代码以符合需要
        wprintf(L"错误: GetModuleHandle 失败\n");
        nRetCode = 1;
    }

    return nRetCode;
}
